<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas cita</title>
    <link rel="stylesheet"href="{{asset('css/style.css') }}"/>

</head>
<body>
    <<nav>
    <img class="logo" src="{{asset ('img/mascotas.jpg')}}"/>
    <a id="pull" href="#">Cita mascotas</a>
    </nav>
    <<h1>Datos de la base de datos</h1>
</body>
</html>